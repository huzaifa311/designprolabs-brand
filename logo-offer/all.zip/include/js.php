<!-- <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript" defer src="assets/js/lib.js"></script> -->
<script type="text/javascript" defer src="assets/js/functions.js" ></script>
<script type="text/javascript" defer src="assets/js/gsap.js" ></script>

<!--Start of Tawk.to Script-->

<script type="text/javascript">
    var Tawk_API = Tawk_API || {},
    Tawk_LoadStart = new Date();
    (function () {
    var s1 = document.createElement("script"),
    s0 = document.getElementsByTagName("script")[0];
    s1.async = true;
    s1.src = "https://embed.tawk.to/67293ec34304e3196add1144/1ibshqbi7";
    s1.charset = "UTF-8";
    s1.setAttribute("crossorigin", "*");
    s0.parentNode.insertBefore(s1, s0);
    })();
</script>
<!--End of Tawk.to Script-->